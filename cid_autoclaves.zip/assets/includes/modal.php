<div class="modal">
    <div class="container-contact">
        <div class="wrap-contact">
            <h1>soy ventana modal</h1>
        </div>
    </div>
</div>